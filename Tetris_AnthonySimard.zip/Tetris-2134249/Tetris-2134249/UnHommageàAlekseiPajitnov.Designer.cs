﻿namespace Tetris_2134249
{
    partial class UnHommageàAlekseiPajitnov
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timerJeu = new System.Windows.Forms.Timer(this.components);
            this.tableauPointage = new System.Windows.Forms.Panel();
            this.lblLignesValue = new System.Windows.Forms.Label();
            this.lblNiveauValue = new System.Windows.Forms.Label();
            this.lblPointsValue = new System.Windows.Forms.Label();
            this.lblLignesTxt = new System.Windows.Forms.Label();
            this.lblNiveauTxt = new System.Windows.Forms.Label();
            this.lblPointsTxt = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.lblGauche = new System.Windows.Forms.Label();
            this.lblBas = new System.Windows.Forms.Label();
            this.lblDroite = new System.Windows.Forms.Label();
            this.btnLigneUP = new System.Windows.Forms.Button();
            this.lvlNextForme = new System.Windows.Forms.Label();
            this.lblForme = new System.Windows.Forms.Label();
            this.tableauPointage.SuspendLayout();
            this.SuspendLayout();
            // 
            // timerJeu
            // 
            this.timerJeu.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tableauPointage
            // 
            this.tableauPointage.Controls.Add(this.lblLignesValue);
            this.tableauPointage.Controls.Add(this.lblNiveauValue);
            this.tableauPointage.Controls.Add(this.lblPointsValue);
            this.tableauPointage.Controls.Add(this.lblLignesTxt);
            this.tableauPointage.Controls.Add(this.lblNiveauTxt);
            this.tableauPointage.Controls.Add(this.lblPointsTxt);
            this.tableauPointage.Location = new System.Drawing.Point(655, 391);
            this.tableauPointage.Name = "tableauPointage";
            this.tableauPointage.Size = new System.Drawing.Size(200, 100);
            this.tableauPointage.TabIndex = 0;
            // 
            // lblLignesValue
            // 
            this.lblLignesValue.AutoSize = true;
            this.lblLignesValue.Location = new System.Drawing.Point(129, 68);
            this.lblLignesValue.Name = "lblLignesValue";
            this.lblLignesValue.Size = new System.Drawing.Size(18, 20);
            this.lblLignesValue.TabIndex = 5;
            this.lblLignesValue.Text = "0";
            // 
            // lblNiveauValue
            // 
            this.lblNiveauValue.AutoSize = true;
            this.lblNiveauValue.Location = new System.Drawing.Point(129, 41);
            this.lblNiveauValue.Name = "lblNiveauValue";
            this.lblNiveauValue.Size = new System.Drawing.Size(18, 20);
            this.lblNiveauValue.TabIndex = 4;
            this.lblNiveauValue.Text = "1";
            // 
            // lblPointsValue
            // 
            this.lblPointsValue.AutoSize = true;
            this.lblPointsValue.Location = new System.Drawing.Point(129, 13);
            this.lblPointsValue.Name = "lblPointsValue";
            this.lblPointsValue.Size = new System.Drawing.Size(18, 20);
            this.lblPointsValue.TabIndex = 3;
            this.lblPointsValue.Text = "0";
            // 
            // lblLignesTxt
            // 
            this.lblLignesTxt.AutoSize = true;
            this.lblLignesTxt.Location = new System.Drawing.Point(17, 68);
            this.lblLignesTxt.Name = "lblLignesTxt";
            this.lblLignesTxt.Size = new System.Drawing.Size(60, 20);
            this.lblLignesTxt.TabIndex = 2;
            this.lblLignesTxt.Text = "Lignes:";
            // 
            // lblNiveauTxt
            // 
            this.lblNiveauTxt.AutoSize = true;
            this.lblNiveauTxt.Location = new System.Drawing.Point(17, 41);
            this.lblNiveauTxt.Name = "lblNiveauTxt";
            this.lblNiveauTxt.Size = new System.Drawing.Size(61, 20);
            this.lblNiveauTxt.TabIndex = 1;
            this.lblNiveauTxt.Text = "Niveau:";
            // 
            // lblPointsTxt
            // 
            this.lblPointsTxt.AutoSize = true;
            this.lblPointsTxt.Location = new System.Drawing.Point(17, 13);
            this.lblPointsTxt.Name = "lblPointsTxt";
            this.lblPointsTxt.Size = new System.Drawing.Size(57, 20);
            this.lblPointsTxt.TabIndex = 0;
            this.lblPointsTxt.Text = "Points:";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(655, 339);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(200, 46);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Demarrer Partie";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lblGauche
            // 
            this.lblGauche.AutoSize = true;
            this.lblGauche.Location = new System.Drawing.Point(651, 282);
            this.lblGauche.Name = "lblGauche";
            this.lblGauche.Size = new System.Drawing.Size(86, 20);
            this.lblGauche.TabIndex = 2;
            this.lblGauche.Text = "A -Gauche";
            // 
            // lblBas
            // 
            this.lblBas.AutoSize = true;
            this.lblBas.Location = new System.Drawing.Point(651, 322);
            this.lblBas.Name = "lblBas";
            this.lblBas.Size = new System.Drawing.Size(57, 20);
            this.lblBas.TabIndex = 3;
            this.lblBas.Text = "S -Bas";
            // 
            // lblDroite
            // 
            this.lblDroite.AutoSize = true;
            this.lblDroite.Location = new System.Drawing.Point(651, 302);
            this.lblDroite.Name = "lblDroite";
            this.lblDroite.Size = new System.Drawing.Size(73, 20);
            this.lblDroite.TabIndex = 4;
            this.lblDroite.Text = "D -Droite";
            // 
            // btnLigneUP
            // 
            this.btnLigneUP.Location = new System.Drawing.Point(743, 282);
            this.btnLigneUP.Name = "btnLigneUP";
            this.btnLigneUP.Size = new System.Drawing.Size(112, 50);
            this.btnLigneUP.TabIndex = 5;
            this.btnLigneUP.Text = "LignesUP";
            this.btnLigneUP.UseVisualStyleBackColor = true;
            this.btnLigneUP.Click += new System.EventHandler(this.btnLigneUP_Click);
            // 
            // lvlNextForme
            // 
            this.lvlNextForme.AutoSize = true;
            this.lvlNextForme.Location = new System.Drawing.Point(651, 259);
            this.lvlNextForme.Name = "lvlNextForme";
            this.lvlNextForme.Size = new System.Drawing.Size(134, 20);
            this.lvlNextForme.TabIndex = 6;
            this.lvlNextForme.Text = "Prochaine Forme:";
            // 
            // lblForme
            // 
            this.lblForme.AutoSize = true;
            this.lblForme.Location = new System.Drawing.Point(791, 259);
            this.lblForme.Name = "lblForme";
            this.lblForme.Size = new System.Drawing.Size(17, 20);
            this.lblForme.TabIndex = 7;
            this.lblForme.Text = "z";
            // 
            // UnHommageàAlekseiPajitnov
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(867, 503);
            this.Controls.Add(this.lblForme);
            this.Controls.Add(this.lvlNextForme);
            this.Controls.Add(this.btnLigneUP);
            this.Controls.Add(this.lblDroite);
            this.Controls.Add(this.lblBas);
            this.Controls.Add(this.lblGauche);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.tableauPointage);
            this.Name = "UnHommageàAlekseiPajitnov";
            this.Text = "Un hommage à Aleksei Pajitnov";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.UnHommageàAlekseiPajitnov_Paint);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.UnHommageàAlekseiPajitnov_KeyDown);
            this.tableauPointage.ResumeLayout(false);
            this.tableauPointage.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timerJeu;
        private System.Windows.Forms.Panel tableauPointage;
        private System.Windows.Forms.Label lblLignesValue;
        private System.Windows.Forms.Label lblNiveauValue;
        private System.Windows.Forms.Label lblPointsValue;
        private System.Windows.Forms.Label lblLignesTxt;
        private System.Windows.Forms.Label lblNiveauTxt;
        private System.Windows.Forms.Label lblPointsTxt;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label lblGauche;
        private System.Windows.Forms.Label lblBas;
        private System.Windows.Forms.Label lblDroite;
        private System.Windows.Forms.Button btnLigneUP;
        private System.Windows.Forms.Label lvlNextForme;
        private System.Windows.Forms.Label lblForme;
    }
}

