﻿//Anthony Simard 2134249 08-12-22 Cree les classes et la structure de base
//Anthony Simard 2134249 08-12-22 Creation moteur jeu
//Anthony Simard 2134249 08-12-22 Creation Events du forms
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TetrisDll;

namespace Tetris_2134249
{
    public partial class UnHommageàAlekseiPajitnov : Form
    {
        MoteurJeu monMoteur = new MoteurJeu(45, Color.LightGray);
        //variables pour le error manager
        static bool DEBUGMODE = false;
        static string PATH = "errorLog.txt";
        public UnHommageàAlekseiPajitnov()
        {
            try
            {
                InitializeComponent();
                this.KeyPreview = true; //lire tous les input clavier, peut importe ou on a clicker
                                        //prevent flicker with double buffering
                this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
                this.UpdateStyles();
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                if (monMoteur.VerifierGravite())
                {
                    this.Refresh();
                }
                lblLignesValue.Text = monMoteur.iNBLignesCompletes.ToString();
                lblPointsValue.Text = monMoteur.iScore.ToString();
                lblNiveauValue.Text = monMoteur.iNiveauCourant.ToString();
            }
            catch (Exception exception)
            {
                errorManager(exception, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
            
        }

        private void DessinerJeu(Graphics g)
        {
            try
            {
                for (int y = 0; y <= monMoteur.AireJeu.GetUpperBound(0); y++)
                {
                    for (int x = 0; x <= monMoteur.AireJeu.GetUpperBound(1); x++) //pour chaque point du tableau de couleur de AireJeu
                    {
                        Rectangle monRectangle = new Rectangle(x * monMoteur.iTailleBloc, y * monMoteur.iTailleBloc, monMoteur.iTailleBloc, monMoteur.iTailleBloc); //definit la zone a dessiner

                        Brush maBrush = new SolidBrush(monMoteur.AireJeu[y, x]); //le pinceau AKA ce qui dessine
                        g.FillRectangle(maBrush, monRectangle); //remplir le rectangle avec nos couleurs
                    }
                }

                if (monMoteur.blocActif != null) //si jai un bloc
                {
                    for (int y = 0; y <= monMoteur.blocActif.ImageBloc.GetUpperBound(0); y++)
                    {
                        for (int x = 0; x <= monMoteur.blocActif.ImageBloc.GetUpperBound(1); x++)
                        {
                            Rectangle monRectangle = new Rectangle((monMoteur.blocActif.iPosX + x) * monMoteur.iTailleBloc, (monMoteur.blocActif.iPosY + y) * monMoteur.iTailleBloc, monMoteur.iTailleBloc, monMoteur.iTailleBloc);

                            Brush maBrush = new SolidBrush(monMoteur.blocActif.ImageBloc[y, x]); //le pinceau AKA ce qui dessine
                            g.FillRectangle(maBrush, monRectangle); //remplir le rectangle avec nos couleurs
                        }
                    }
                }
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
            
        }
        private void UnHommageàAlekseiPajitnov_Paint(object sender, PaintEventArgs e) //evenements pour dessiner (se fait call a chaque refresh)
        {
            try
            {
                DessinerJeu(e.Graphics);
            }
            catch (Exception exception)
            {
                errorManager(exception, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            //constantes des valeurs initiales
            const string LIGNESVALUE = "O";
            const string POINTSVALUE = "O";
            const string NIVEAUVALUE = "1";
            try
            {
                monMoteur.StartGame(); //start tout
                this.Refresh(); //call paint
                timerJeu.Enabled = true; //start timer
                //reintialiser les valeurs
                lblLignesValue.Text = LIGNESVALUE;
                lblPointsValue.Text = POINTSVALUE;
                lblNiveauValue.Text = NIVEAUVALUE;
                monMoteur.iNBMillisec = 1000;
                monMoteur.iNiveauCourant = 1;
                monMoteur.iNBLignesCompletes = 0;
            }
            catch (Exception exception)
            {
                errorManager(exception, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
        }

        public static void errorManager(Exception exception, string sFunctionName)
        {
            //Générer l'erreur détaillée
            string sDetailledError = DateTime.Now + "|Une erreur s'est produite dans la fonction "
                + sFunctionName + " :"
                + exception.Message;

            //If debug mode
            if (DEBUGMODE)
            {   //Affiche l'erreur détaillé à l'écran
                Console.WriteLine(sDetailledError);
            }

            //Ouvrir le fichier
            StreamWriter writer = new StreamWriter(PATH, true);

            //Écrire dans le fichier texte
            writer.WriteLine(sDetailledError);

            //Fermer le fichier
            writer.Close();

            MessageBox.Show("Une erreur est survenue:" + exception.Message);
        }

        private void UnHommageàAlekseiPajitnov_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                switch (e.KeyCode)
                {
                    case Keys.D:
                        if (monMoteur.BougerDroite())
                        {
                            this.Refresh();
                        }
                        break;
                    case Keys.S:
                        if (monMoteur.BougerBas())
                        {
                            this.Refresh();
                        }
                        break;
                    case Keys.A:
                        if (monMoteur.BougerGauche())
                        {
                            this.Refresh();
                        }
                        break;
                    default:
                        break;
                }
            }
            catch (Exception exception)
            {
                errorManager(exception, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
            
        }

        private void btnLigneUP_Click(object sender, EventArgs e)
        {
            try
            {
                double tempTimer = monMoteur.iNBMillisec;
                monMoteur.iNBLignesCompletes++;
                monMoteur.iNiveauCourant = Convert.ToInt32(monMoteur.iNBLignesCompletes / 5); //convert va round down vs cast qui round up
                for (int i = 1; i < monMoteur.iNiveauCourant; i++)
                {
                    tempTimer *= 0.9;
                    monMoteur.iNBMillisec = Convert.ToInt32(tempTimer); //deplacer ailleurs plus tard
                }
            }
            catch (Exception exception)
            {
                errorManager(exception, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
            
        }
    }
}
