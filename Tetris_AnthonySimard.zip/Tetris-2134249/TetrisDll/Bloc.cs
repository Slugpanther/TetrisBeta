﻿//Anthony Simard 2134249 08-12-22 Cree les classes et la structure de base

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;

namespace TetrisDll
{
    public class Bloc
    {
        //variables
        int iposX = 4;
        int iposY = 0;
        private Color[,] imageBloc = new Color[4, 4];
        //variables pour le error manager
        static bool DEBUGMODE = false;
        static string PATH = "errorLog.txt";

        //getter et setters
        public int iPosX
        {
            get => iposX;
            set
            {
                try
                {
                    iposX = value;
                }
                catch (Exception e)
                {
                    errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
                }
            }
        }


        public int iPosY
        {
            get => iposY;
            set
            {
                try
                {
                    if (value < 0) //si valeur plus petite que 0
                    {
                        value = 0;
                    }
                    iposY = value;
                }
                catch (Exception e)
                {
                    errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
                }

            }
        }

        public Color[,] ImageBloc { get => imageBloc; set => imageBloc = value; }

        //Methodes

        public Bloc Clone()
        {
            try
            {
                Bloc blocClone = new Bloc(); //cree new bloc et associe les valeurs courantes au clone
                blocClone.iPosX = iPosX;
                blocClone.iPosY = iPosY;
                blocClone.imageBloc = new Color[4, 4]; //associe la taille aux memes dimensions

                for (int tempY = 0; tempY <= imageBloc.GetUpperBound(0); tempY++)
                {
                    for (int tempX = 0; tempX <= imageBloc.GetUpperBound(1); tempX++) //for imbriques pour parcourir toutes les images du tableau a 2 dimensions
                    {
                        blocClone.imageBloc[tempY, tempX] = imageBloc[tempY, tempX]; //associe les valeurs de base au clone pour chaque position
                    }
                }
                return blocClone;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
                return null; //ne sera jamais call car errorManager close
            }
            
        }






        public static void errorManager(Exception exception, string sFunctionName)
        {
            //Générer l'erreur détaillée
            string sDetailledError = DateTime.Now + "|Une erreur s'est produite dans la fonction "
                + sFunctionName + " :"
                + exception.Message;

            //If debug mode
            if (DEBUGMODE)
            {   //Affiche l'erreur détaillé à l'écran
                Console.WriteLine(sDetailledError);
            }

            //Ouvrir le fichier
            StreamWriter writer = new StreamWriter(PATH, true);

            //Écrire dans le fichier texte
            writer.WriteLine(sDetailledError);

            //Fermer le fichier
            writer.Close();

            Console.WriteLine("Une erreur est survenue.");
            Console.ReadKey();
        }
    }
}
