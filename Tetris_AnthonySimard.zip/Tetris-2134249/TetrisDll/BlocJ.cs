﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisDll
{
    public class BlocJ:Bloc
    {
        public BlocJ()
        {
            try
            {
                ImageBloc[0, 2] = Color.Green;
                ImageBloc[1, 2] = Color.Green;
                ImageBloc[2, 1] = Color.Green;
                ImageBloc[2, 2] = Color.Green;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
            
        }
    }
}
