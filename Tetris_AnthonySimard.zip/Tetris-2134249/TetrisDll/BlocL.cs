﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisDll
{
    public class BlocL:Bloc
    {
        public BlocL()
        {
            try
            {
                ImageBloc[0, 2] = Color.Blue;
                ImageBloc[1, 2] = Color.Blue;
                ImageBloc[2, 2] = Color.Blue;
                ImageBloc[2, 3] = Color.Blue;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
            
        }
    }
}
