﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisDll
{
    public class BlocS:Bloc
    {
        public BlocS()
        {
            try
            {
                ImageBloc[0, 2] = Color.Pink;
                ImageBloc[0, 3] = Color.Pink;
                ImageBloc[1, 1] = Color.Pink;
                ImageBloc[1, 2] = Color.Pink;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
        }
    }
}
