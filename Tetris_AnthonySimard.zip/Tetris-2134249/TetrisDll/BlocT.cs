﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisDll
{
    public class BlocT:Bloc
    {
        public BlocT()
        {
            try
            {
                ImageBloc[0, 1] = Color.Magenta;
                ImageBloc[0, 2] = Color.Magenta;
                ImageBloc[0, 3] = Color.Magenta;
                ImageBloc[1, 2] = Color.Magenta;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
        }
    }
}
