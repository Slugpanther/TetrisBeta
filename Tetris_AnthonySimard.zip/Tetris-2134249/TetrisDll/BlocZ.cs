﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisDll
{
    public class BlocZ:Bloc
    {
        public BlocZ()
        {
            try
            {
                ImageBloc[0, 1] = Color.LightBlue;
                ImageBloc[0, 2] = Color.LightBlue;
                ImageBloc[1, 2] = Color.LightBlue;
                ImageBloc[1, 3] = Color.LightBlue;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
        }
    }
}
