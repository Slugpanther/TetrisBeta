﻿//Anthony Simard 2134249 08-12-22 Cree les classes et la structure de base
//Anthony Simard 2134249 08-12-22 Creation moteur jeu

using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisDll
{
    public class MoteurJeu
    {

        Color[,] aireJeu = new Color[22,10]; //recheck si 10,22 ou 22,10
        public int iTailleBloc = 45;
        public  Color couleurDeFond = Color.LightGray;
        public Bloc blocActif;
        public Bloc prochainBloc = new BlocZ(); //prochain bloc initial
        public int iScore = 0;
        public int iNiveauCourant = 1;
        public int iNBLignesCompletes = 0;
        public DateTime tempsDernierMovement;
        public int iNBMillisec = 1000; //vitesse du jeu 

        //variables pour le error manager
        static bool DEBUGMODE = false;
        static string PATH = "errorLog.txt";

        public MoteurJeu(int iTailleBlocs,Color couleurFond)
        {
            try
            {
                iTailleBloc = iTailleBlocs;
                couleurDeFond = couleurFond;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
            
        }

        public Color[,] AireJeu { get => aireJeu; private set => aireJeu = value; }


        //Methodes
        public void StartGame()
        {
            try
            {
                int iPieceRandom;
                iScore = 0;
                for (int tempY = 0; tempY <= aireJeu.GetUpperBound(0); tempY++)
                {
                    for (int tempX = 0; tempX <= aireJeu.GetUpperBound(1); tempX++)
                    {
                        aireJeu[tempY, tempX] = couleurDeFond;
                    }
                }
                iPieceRandom = RNG.oRandom.Next(1, 8);
                switch (iPieceRandom)
                {
                    case 1:
                        blocActif = new BlocI();
                        break;
                    case 2:
                        blocActif = new BlocJ();
                        break;
                    case 3:
                        blocActif = new BlocL();
                        break;
                    case 4:
                        blocActif = new BlocO();
                        break;
                    case 5:
                        blocActif = new BlocS();
                        break;
                    case 6:
                        blocActif = new BlocT();
                        break;
                    case 7:
                        blocActif = new BlocZ();
                        break;
                    default:
                        break;
                }
                //definir prochain bloc au hasard
                /*iPieceRandom = RNG.oRandom.Next(1, 8);
                switch (iPieceRandom)
                {
                    case 1:
                        prochainBloc = new BlocI();
                        break;
                    case 2:
                        prochainBloc = new BlocJ();
                        break;
                    case 3:
                        prochainBloc = new BlocL();
                        break;
                    case 4:
                        prochainBloc = new BlocO();
                        break;
                    case 5:
                        prochainBloc = new BlocS();
                        break;
                    case 6:
                        prochainBloc = new BlocT();
                        break;
                    case 7:
                        prochainBloc = new BlocZ();
                        break;
                    default:
                        break;
                }*/
                //testing
                tempsDernierMovement = DateTime.Now;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
            
        }

        public bool TesterPosition(Bloc ceBloc)
        {
            try
            {
                for (int tempY = 0; tempY <= ceBloc.ImageBloc.GetUpperBound(0); tempY++)
                {
                    for (int tempX = 0; tempX <= ceBloc.ImageBloc.GetUpperBound(1); tempX++) //for imbriquer pour verifier les 2 dimensions du tableau du bloc
                    {
                        if (ceBloc.ImageBloc[tempY, tempX].IsNamedColor) //si cette partie du tableau n'est pas sans couleur
                        {
                            if (ceBloc.iPosY + tempY < 0 || ceBloc.iPosX + tempX < 0 || ceBloc.iPosY > aireJeu.GetUpperBound(0))
                            {
                                return false;
                            }
                            //si le carre du bloc entre en collision avec autre chose que le fond
                            if (aireJeu[ceBloc.iPosY + tempY, ceBloc.iPosX + tempX].Name != couleurDeFond.Name)
                            {
                                return false;
                            }
                        }
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
                return false;
            }
            
        }

        public bool BougerGauche()
        {
            try
            {
                Bloc tempBloc = blocActif.Clone(); //clone == creer un nouveau objet et copier manuellement tout ce qui est dedans
                tempBloc.iPosX--; //aller vers la gauche le bloc temporaire
                tempsDernierMovement = DateTime.Now; //updater le dernier movement a maintenant

                if (TesterPosition(tempBloc)) //si la valeur temporaire peut bouger
                {
                    blocActif = tempBloc; //donner les valeurs au vrai bloc
                    return true; //vrai va faire bouger
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
                return false;
            }
            
        }
        public bool BougerDroite()
        {
            try
            {
                Bloc tempBloc = blocActif.Clone(); //clone == creer un nouveau objet et copier manuellement tout ce qui est dedans
                tempBloc.iPosX++;
                tempsDernierMovement = DateTime.Now;

                if (TesterPosition(tempBloc))
                {
                    blocActif = tempBloc;
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
                return false;
            }
            
        }

        public bool BougerBas()
        {
            try
            {
                Bloc tempBloc = blocActif.Clone(); //clone == creer un nouveau objet et copier manuellement tout ce qui est dedans
                tempBloc.iPosY++; //aller vers la gauche le bloc temporaire
                tempsDernierMovement = DateTime.Now; //updater le dernier movement a maintenant

                if (TesterPosition(tempBloc)) //si la valeur temporaire peut bouger
                {
                    blocActif = tempBloc; //donner les valeurs au vrai bloc
                    return true; //vrai va faire bouger
                }
                else
                {
                    Fusion();
                    return false;
                }
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
                return false;
            }
            
        }
        public void Fusion()
        {
            try
            {
                int iPieceRandom;
                for (int tempY = 0; tempY <= blocActif.ImageBloc.GetUpperBound(0); tempY++)
                {
                    for (int tempX = 0; tempX <= blocActif.ImageBloc.GetUpperBound(1); tempX++)
                    {
                        if (blocActif.ImageBloc[tempY, tempX].IsNamedColor) //si cette partie du tableau n'est pas sans couleur
                        {
                            aireJeu[blocActif.iPosY + tempY, blocActif.iPosX + tempX] = blocActif.ImageBloc[tempY, tempX];
                        }
                    }

                }
                iPieceRandom = RNG.oRandom.Next(1, 8); //randomly choose un bloc
                switch (iPieceRandom) //selon la valeur, cree nouveau bloc d'une certaine forme
                {
                    case 1:
                        blocActif = new BlocI();
                        break;
                    case 2:
                        blocActif = new BlocJ();
                        break;
                    case 3:
                        blocActif = new BlocL();
                        break;
                    case 4:
                        blocActif = new BlocO();
                        break;
                    case 5:
                        blocActif = new BlocS();
                        break;
                    case 6:
                        blocActif = new BlocT();
                        break;
                    case 7:
                        blocActif = new BlocZ();
                        break;
                    default:
                        break;
                }
                iScore += 100;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
            }
            
        }
        //overlap non-complet

      /*public bool Overlap(Bloc ceBloc)
        {
            try
            {
                if (ceBloc.iPosY < 0)
                {
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
                return true;
            }
        }*/

        public bool VerifierGravite()
        {
            try
            {
                if (DateTime.Now.Subtract(tempsDernierMovement).TotalMilliseconds >= iNBMillisec) //si le temps entre maintenant et le dernier movement est plus grand ou egal au temps entre des movement voulu
                {
                    tempsDernierMovement = DateTime.Now; //dernier movement = maintenant
                    return BougerBas();
                }
                return false;
            }
            catch (Exception e)
            {
                errorManager(e, System.Reflection.MethodBase.GetCurrentMethod().Name); //call le error manager
                return false;
            }
            
        }

        //meme que Bloc, mais on ne veut pas l'heriter alors jai remis la meme fonction.
        public static void errorManager(Exception exception, string sFunctionName)
        {
            //Générer l'erreur détaillée
            string sDetailledError = DateTime.Now + "|Une erreur s'est produite dans la fonction "
                + sFunctionName + " :"
                + exception.Message;

            //If debug mode
            if (DEBUGMODE)
            {   //Affiche l'erreur détaillé à l'écran
                Console.WriteLine(sDetailledError);
            }

            //Ouvrir le fichier
            StreamWriter writer = new StreamWriter(PATH, true);

            //Écrire dans le fichier texte
            writer.WriteLine(sDetailledError);

            //Fermer le fichier
            writer.Close();

            Console.WriteLine("Une erreur est survenue." + exception.Message);
        }
    }
}
